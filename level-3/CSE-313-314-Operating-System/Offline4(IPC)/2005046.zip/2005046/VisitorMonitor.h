#ifndef VISITOR_MONITOR_H
#define VISITOR_MONITOR_H

#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>
#include "print.h"

int stair_delay = 1;
int corridor_delay = 2;
int rc = 0;                                               // Number of active readers (standard visitors)
int wc = 0;                                               // Number of waiting or active writers (premium visitors)
pthread_mutex_t rc_lock = PTHREAD_MUTEX_INITIALIZER;      // Mutex for rc
pthread_mutex_t wc_lock = PTHREAD_MUTEX_INITIALIZER;      // Mutex for wc
pthread_mutex_t access_mutex = PTHREAD_MUTEX_INITIALIZER; // Mutex for access control
pthread_mutex_t db = PTHREAD_MUTEX_INITIALIZER;           // Mutex for the photo booth

class VisitorMonitor
{
private:
    sem_t gallery1_sem;
    sem_t corridor_sem;
    pthread_mutex_t stairs_lock[3];
    int gallery1_capacity;
    int max_corridor_visitors;

public:
    VisitorMonitor(int gallery1_cap, int corridor_cap) : gallery1_capacity(gallery1_cap), max_corridor_visitors(corridor_cap)
    {
        sem_init(&gallery1_sem, 0, gallery1_capacity);     // Initialize Gallery 1 semaphore
        sem_init(&corridor_sem, 0, max_corridor_visitors); // Initialize Corridor semaphore

        for (int i = 0; i < 3; ++i)
        {
            pthread_mutex_init(&stairs_lock[i], nullptr); // Initialize mutexes for stairs
        }
    }

    ~VisitorMonitor()
    {
        sem_destroy(&gallery1_sem);
        sem_destroy(&corridor_sem);

        for (int i = 0; i < 3; ++i)
        {
            pthread_mutex_destroy(&stairs_lock[i]);
        }
    }

    void enterHallway(int visitor_id, int hallwayVisitingTime)
    {
        logPrint("has arrived at A (entered the Hallway)", visitor_id);
        sleep(hallwayVisitingTime);
        logPrint("has arrived at B (wants to exit the hallway)", visitor_id);
    }

    void useStairs(int visitor_id)
    {
        // Step 0: Attempt to lock and move to Step 1
        // logPrint("is attempting to lock step 0", visitor_id);
        pthread_mutex_lock(&stairs_lock[0]);
        // logPrint("locked step 0", visitor_id);
        logPrint("at step 0", visitor_id);
        sleep(1);

        // logPrint("is attempting to lock step 1", visitor_id);
        pthread_mutex_lock(&stairs_lock[1]);
        // logPrint("locked step 1", visitor_id);
        logPrint("at step 1", visitor_id);
        pthread_mutex_unlock(&stairs_lock[0]);
        // logPrint("unlocked step 0", visitor_id);
        sleep(1);

        // Step 1: Attempt to move to Step 2
        // logPrint("is attempting to lock step 2", visitor_id);
        pthread_mutex_lock(&stairs_lock[2]);
        // logPrint("locked step 2", visitor_id);
        logPrint("at step 2", visitor_id);
        pthread_mutex_unlock(&stairs_lock[1]);
        // logPrint("unlocked step 1", visitor_id);
        sleep(1);

        // Step 2: Attempt to enter Gallery 1
        logPrint("is attempting to enter Gallery 1 from step 2", visitor_id);
        sem_wait(&gallery1_sem); // Wait for Gallery 1 slot
        logPrint("entered Gallery 1 at C from step 2", visitor_id);
        pthread_mutex_unlock(&stairs_lock[2]);
        // logPrint("unlocked step 2", visitor_id);
    }

    void exitGallery1(int visitor_id)
    {
        enterCorridor(visitor_id);
    }

    void enterCorridor(int visitor_id)
    {
        // logPrint("is attempting to enter the Corridor", visitor_id);
        sem_wait(&corridor_sem); // Wait for Corridor slot
        logPrint("is exiting Gallery 1", visitor_id);
        sem_post(&gallery1_sem); // Release Gallery 1 slot
        logPrint("entered the Corridor", visitor_id);
        sleep(corridor_delay);
    }

    void exitCorridor(int visitor_id)
    {
        logPrint("is exiting the Corridor", visitor_id);
        sem_post(&corridor_sem); // Release Corridor slot
    }

    void enterGallery2(int visitor_id)
    {
        logPrint("has arrived at E (entered Gallery 2)", visitor_id);
    }

    void enterPhotoBooth(int visitor_id, bool is_premium, int timeInPhotoBooth)
    {
        if (is_premium)
        {
            
            logPrint("\033[1;35mis about to enter the photo booth with priority\033[0m", visitor_id); // Magenta for premium
            // Premium visitor (Writer) behavior
            pthread_mutex_lock(&wc_lock);
            wc++;
            if (wc == 1)
            {
                pthread_mutex_lock(&access_mutex); // Block readers
            }
            pthread_mutex_unlock(&wc_lock);


            pthread_mutex_lock(&db);                                                          // Exclusive access to the photo booth
            logPrint("\033[1;35mis inside the photo booth with priority\033[0m", visitor_id); // Magenta for premium
            sleep(timeInPhotoBooth);  
            logPrint("\033[1;35mhas left the photo booth with priority\033[0m", visitor_id);                                                        // Simulate photo booth time
            pthread_mutex_unlock(&db);

            pthread_mutex_lock(&wc_lock);
            wc--;
            if (wc == 0)
            {
                pthread_mutex_unlock(&access_mutex); // Allow readers if no writers are waiting
            }
            pthread_mutex_unlock(&wc_lock);

            
        }
        else
        {
            logPrint("\033[1;36mis about to enter the shared photo booth\033[0m", visitor_id); // Cyan for standard
            // Standard visitor (Reader) behavior
            pthread_mutex_lock(&access_mutex);
            pthread_mutex_lock(&rc_lock);
            rc++;
            if (rc == 1)
            {
                pthread_mutex_lock(&db); // Block writers
            }
            pthread_mutex_unlock(&rc_lock);
            pthread_mutex_unlock(&access_mutex);

            
            logPrint("\033[1;36mis inside the shared photo booth\033[0m", visitor_id);         // Cyan for standard
            sleep(timeInPhotoBooth);   
            logPrint("\033[1;36mhas left the shared photo booth\033[0m", visitor_id);                                                        // Simulate photo booth time

            pthread_mutex_lock(&rc_lock);
            rc--;
            if (rc == 0)
            {
                pthread_mutex_unlock(&db); // Release photo booth for writers
            }
            pthread_mutex_unlock(&rc_lock);

            
        }
    }
}
;

#endif
