#include <iostream>
#include <vector>
#include <pthread.h>
#include <unistd.h>
#include <random>
#include <chrono>
#include <algorithm>
#include "VisitorMonitor.h"


int N, M, w, x, y, z;
VisitorMonitor *monitor;


const double lambda = 2.0; // Inter-arrival rate (events per second)
unsigned seed = 2005046;
std::default_random_engine generator(seed);
std::poisson_distribution<int> distribution(lambda);

void *visitMuseum(void *arg)
{
    int visitor_id = *((int *)arg);
    bool is_premium = (visitor_id >= 2001);

    delete (int *)arg;

    // Simulate the visitor's random arrival delay
    int arrival_delay = distribution(generator);
    sleep(arrival_delay);

    monitor->enterHallway(visitor_id, w);
    // sleep(w);

    monitor->useStairs(visitor_id);
    // monitor->enterGallery1(visitor_id); //handled after the use Stair
    sleep(x); // spending time in the gallery
    monitor->exitGallery1(visitor_id);

    // monitor->enterCorridor(visitor_id);
    // corridor delay one
    monitor->exitCorridor(visitor_id);

    monitor->enterGallery2(visitor_id);
    sleep(y);
    monitor->enterPhotoBooth(visitor_id, is_premium, z);
    // sleep(z);

    pthread_exit(NULL);
}

int main(int argc, char *argv[])
{

    if (argc != 7) {
        std::cerr << "Usage: " << argv[0] << " N M w x y z" << std::endl;
        return 1;
    }
    
    N = std::atoi(argv[1]); // Convert string to int
    M = std::atoi(argv[2]);
    w = std::atoi(argv[3]); // Convert string to float
    x = std::atoi(argv[4]);
    y = std::atoi(argv[5]);
    z = std::atoi(argv[6]);

    std::cout << "N (friends): " << N << std::endl;
    std::cout << "M (premium visitors): " << M << std::endl;
    std::cout << "w: " << w << ", x: " << x << ", y: " << y << ", z: " << z << std::endl;

    // std::cout << "Enter N (friends), M (premium visitors), w, x, y, z: ";
    // std::cin >> N >> M >> w >> x >> y >> z;

    pthread_mutex_init(&stdout_lock, nullptr);
    start_time = std::chrono::high_resolution_clock::now();

    monitor = new VisitorMonitor(5, 3); // Gallery 1 has 5 slots, corridor allows 3 visitors

    std::vector<int> visitor_ids;
    for (int i = 0; i < N; ++i)
        visitor_ids.push_back(1001 + i); // Normal visitors
    for (int i = 0; i < M; ++i)
        visitor_ids.push_back(2001 + i); // Premium visitors

    std::shuffle(visitor_ids.begin(), visitor_ids.end(), generator);

    // Create threads for shuffled visitor IDs
    std::vector<pthread_t> visitor_threads(visitor_ids.size());
    for (size_t i = 0; i < visitor_ids.size(); ++i)
    {
        int *id = new int(visitor_ids[i]); // Use shuffled ID
        pthread_create(&visitor_threads[i], nullptr, visitMuseum, id);
    }

    // Wait for all threads to finish
    for (auto &thread : visitor_threads)
    {
        pthread_join(thread, nullptr);
    }

    delete monitor;
    pthread_mutex_destroy(&stdout_lock);

    return 0;
}
