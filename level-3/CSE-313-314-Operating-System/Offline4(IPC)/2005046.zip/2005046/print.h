// print.h
#ifndef PRINT_H
#define PRINT_H

#include <iostream>
#include <vector>
#include <semaphore.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <chrono>

using namespace std;
// freopen("output.txt","w",stdout);

pthread_mutex_t stdout_lock;
std::chrono::high_resolution_clock::time_point start_time;

double getCurrentTime()
{
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - start_time).count() / 1000.0;
}

template <typename T>
void print(T var1)
{
    std::cout << var1 << std::endl;
}

template <typename T, typename... Types>
void print(T var1, Types... var2)
{
    std::cout << var1 << " ";
    print(var2...);
}

template <typename... Types>
void logPrint(const std::string &action, int visitor_id, Types... args)
{
    pthread_mutex_lock(&stdout_lock);
    double timestamp = getCurrentTime();

    // Apply color formatting based on the action
    if (action.find("has arrived at A") != std::string::npos)
    {
        std::cout << "\033[1;33m"; // Bold Yellow for arrival
    }
    else if (action.find("is on step") != std::string::npos || action.find("is attempting to step") != std::string::npos)
    {
        std::cout << "\033[1;34m"; // Bold Blue for stairs
    }
    else if (action.find("entered Gallery 1") != std::string::npos)
    {
        std::cout << "\033[1;32m"; // Bold Green for entering Gallery 1
    }
    else if (action.find("exiting Gallery 1") != std::string::npos)
    {
        std::cout << "\033[1;31m"; // Bold Red for exiting Gallery 1
    }
    else if (action.find("has arrived at B") != std::string::npos)
    {
        std::cout << "\033[1;35m"; // Bold Magenta (Pink)
    }
    else if (action.find("entered the Corridor") != std::string::npos)
    {
        std::cout << "\033[1;36m"; // Sky Blue for entering the Corridor
    }
    else if (action.find("has arrived at E (entered Gallery 2)") != std::string::npos)
    {
        std::cout << "\033[38;5;214m"; // Orange for entering Gallery 2
    }
     else if (action.find("is exiting the Corridor") != std::string::npos)
    {
        std::cout << "\033[38;5;93m"; // Purple
    }

    // Print the formatted log message
    std::cout << "Visitor " << visitor_id << " " << action;
    (std::cout << " " << ... << args); // Print additional arguments
    std::cout << " at timestamp " << timestamp << std::endl;

    // Reset text formatting to default
    std::cout << "\033[0m"; // Reset formatting
    pthread_mutex_unlock(&stdout_lock);
}

#endif
