#!/bin/bash
id=2005031
num_flows=1
bandwith=3
prot1="TcpHighSpeed"
prot2="TcpLedbat"
prot=$prot1
if [ $1 == 2 ]; then
    prot=$prot2
fi
./ns3 run "scratch/tcp-variants-comparison.cc --tracing=1 --num_flows=${num_flows} --bandwidth=${bandwith}Mbps --transport_prot=$prot"
